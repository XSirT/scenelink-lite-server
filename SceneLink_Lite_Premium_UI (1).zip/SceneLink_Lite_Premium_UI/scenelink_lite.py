# -*- coding: utf-8 -*-
# SceneLink Lite Online Client - original implementation for SFM PySide/Python 2.7
# Uses QtNetwork for HTTPS. Never bypass certificate errors.
# Supports online presence, friends, parties, host-approved join requests, roles and party text chat.
# Voice chat, image transfer, and live SFM scene/animation synchronization are not implemented yet.

from __future__ import print_function
import os, json, time, traceback

try:
    from PySide import QtGui, QtCore, QtNetwork
except Exception:
    try:
        from PySide2 import QtWidgets as QtGui, QtCore, QtNetwork
    except Exception:
        QtGui = None
        QtCore = None
        QtNetwork = None

APP = None
WINDOW = None
CONFIG_PATH = os.path.join(os.path.expanduser("~"), "scenelink_lite_settings.json")
DARK = """
QWidget {
 background:#1d1e23; color:#f3f4f8;
 font-family:'Segoe UI'; font-size:9pt;
}
QDialog { background:#1d1e23; }
QLabel { background:transparent; border:0; }
QLabel#muted { color:#a3a7b3; }
QLabel#section { color:#f4f5fa; font-size:11pt; font-weight:600; }
QFrame#card {
 background:#282a31; border:1px solid #363943; border-radius:13px;
}
QFrame#hero {
 background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #292c36,stop:1 #23252c);
 border:1px solid #3c4050; border-radius:14px;
}
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QListWidget {
 background:#191a1f; color:#f3f4f8; border:1px solid #41444f;
 border-radius:8px; padding:8px;
 selection-background-color:#477ff0;
}
QLineEdit:focus, QTextEdit:focus, QComboBox:focus {
 border:1px solid #659bff;
}
QPushButton {
 background:#343740; color:#f5f6fb; border:1px solid #3b3e49;
 border-radius:9px; padding:9px 13px; font-weight:600;
}
QPushButton:hover {
 background:#414653; border:1px solid #545a6c;
}
QPushButton:pressed {
 background:#292c34; border:1px solid #4d5260; padding-top:10px; padding-bottom:8px;
}
QPushButton#primary {
 background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #4b91ff,stop:1 #3478ed);
 border:1px solid #4c8df5; color:white; font-weight:700;
}
QPushButton#primary:hover {
 background:qlineargradient(x1:0,y1:0,x2:0,y2:1,stop:0 #68a2ff,stop:1 #4388fb);
 border:1px solid #7db0ff;
}
QPushButton#primary:pressed {
 background:#2f6bd0; border:1px solid #2f6bd0; padding-top:10px; padding-bottom:8px;
}
QPushButton#danger {
 color:#ff747d; border:1px solid #6a383f; background:transparent;
}
QPushButton#danger:hover { background:#39252a; border:1px solid #a24a55; }
QPushButton#quiet { background:transparent; border:1px solid transparent; color:#aeb3c0; }
QPushButton#quiet:hover { background:#2b2d35; border:1px solid #3a3d48; color:#ffffff; }
QCheckBox { spacing:8px; }
QScrollArea { border:0; background:transparent; }
QSlider::groove:horizontal { height:4px; background:#454957; border-radius:2px; }
QSlider::handle:horizontal { background:#76a8ff; width:12px; margin:-5px 0; border-radius:6px; }
"""

def load_config():
    try:
        f=open(CONFIG_PATH,"r")
        d=json.load(f); f.close()
        return d
    except Exception:
        return {}
def save_config(d):
    try:
        f=open(CONFIG_PATH,"w")
        json.dump(d,f,indent=2); f.close()
    except Exception:
        pass
def log_exception():
    try:
        f=open(os.path.join(os.path.expanduser("~"),"scenelink_lite_debug.log"),"a")
        f.write("\n[%s]\n%s\n"%(time.strftime("%Y-%m-%d %H:%M:%S"),traceback.format_exc())); f.close()
    except Exception:
        pass
def btn(text, primary=False, danger=False):
    b=QtGui.QPushButton(text)
    if primary: b.setObjectName("primary")
    if danger: b.setObjectName("danger")
    return b

class SceneLinkWindow(QtGui.QDialog):
    def __init__(self,parent=None):
        QtGui.QDialog.__init__(self,parent)
        self.setWindowTitle("SceneLink Lite")
        self.resize(520,760); self.setMinimumSize(460,620)
        self.setStyleSheet(DARK)
        self.config=load_config()
        self.party=None
        self.community_tab="Friends"
        self.last_message_id=0
        self.manager=QtNetwork.QNetworkAccessManager(self) if QtNetwork is not None else None
        self.timer=QtCore.QTimer(self)
        self.timer.timeout.connect(self.online_tick)
        self.pages=QtGui.QStackedWidget()
        root=QtGui.QVBoxLayout(self)
        root.setContentsMargins(12,10,12,10); root.setSpacing(8)
        self._header(root)
        root.addWidget(self.pages,1)
        self._nickname_page()
        self._home_page()
        self._community_page()
        self._create_page()
        self._join_page()
        self._party_page()
        self._settings_page()
        self.show_first_page()
        if self.config.get("service_url"):
            self.connect_online()

    def _header(self,root):
        row=QtGui.QHBoxLayout()
        logo=QtGui.QLabel("SL"); logo.setStyleSheet("font-size:18px;color:#7f8cff;font-weight:bold;")
        title=QtGui.QLabel("SceneLink Lite"); title.setStyleSheet("font-size:15px;font-weight:bold;")
        row.addWidget(logo); row.addWidget(title); row.addStretch(1)
        self.lang=QtGui.QComboBox(); self.lang.addItems(["English"]); self.lang.setMaximumWidth(100); row.addWidget(self.lang)
        people=btn("People"); people.clicked.connect(self.show_community); row.addWidget(people)
        settings=btn("Settings"); settings.clicked.connect(self.open_settings); row.addWidget(settings)
        root.addLayout(row)

    def show_first_page(self):
        self.pages.setCurrentWidget(self.nick_page if not self.config.get("nickname") else self.home_page)

    def _nickname_page(self):
        self.nick_page=QtGui.QWidget(); v=QtGui.QVBoxLayout(self.nick_page); v.addStretch(2)
        avatar=QtGui.QLabel("O"); avatar.setAlignment(QtCore.Qt.AlignCenter); avatar.setStyleSheet("font-size:54px;color:#3987f5;")
        v.addWidget(avatar)
        title=QtGui.QLabel("Choose your nickname"); title.setAlignment(QtCore.Qt.AlignCenter); title.setStyleSheet("font-size:19px;font-weight:bold;"); v.addWidget(title)
        note=QtGui.QLabel("This is how other players will see you."); note.setObjectName("muted"); note.setAlignment(QtCore.Qt.AlignCenter); v.addWidget(note)
        self.nick=QtGui.QLineEdit(self.config.get("nickname","")); self.nick.setPlaceholderText("Nickname"); self.nick.setMaxLength(20); v.addWidget(self.nick)
        hint=QtGui.QLabel("3-20 characters: letters, numbers, spaces, _ and -"); hint.setObjectName("muted"); v.addWidget(hint)
        cont=btn("Continue",True); cont.clicked.connect(self.save_nickname); v.addWidget(cont)
        v.addStretch(3); self.pages.addWidget(self.nick_page)

    def _home_page(self):
        self.home_page=QtGui.QWidget()
        outer=QtGui.QVBoxLayout(self.home_page)
        outer.setContentsMargins(8,8,8,8)
        outer.setSpacing(12)

        self.welcome=QtGui.QLabel("Welcome back, %s" % self.config.get("nickname","Creator"))
        self.welcome.setStyleSheet("font-size:21px;font-weight:700;color:#f5f6fb;")
        outer.addWidget(self.welcome)

        self.connection_label=QtGui.QLabel("Online service not configured yet. Set the HTTPS URL in Settings.")
        self.connection_label.setObjectName("muted")
        self.connection_label.setWordWrap(True)
        outer.addWidget(self.connection_label)

        hero=QtGui.QFrame(); hero.setObjectName("hero")
        hv=QtGui.QVBoxLayout(hero); hv.setContentsMargins(16,14,16,14); hv.setSpacing(8)
        top=QtGui.QHBoxLayout()
        pkg=QtGui.QLabel("SCENELINK LITE")
        pkg.setStyleSheet("font-size:12px;font-weight:800;letter-spacing:1px;color:#aac6ff;")
        top.addWidget(pkg)
        top.addStretch(1)
        edition=QtGui.QLabel("COMMUNITY BUILD")
        edition.setStyleSheet("font-size:8pt;color:#7fe0b1;font-weight:700;")
        top.addWidget(edition)
        hv.addLayout(top)
        headline=QtGui.QLabel("Make scenes together.")
        headline.setStyleSheet("font-size:16px;font-weight:700;")
        hv.addWidget(headline)
        desc=QtGui.QLabel("Create a party, invite your team, and keep your session details in one place.")
        desc.setObjectName("muted"); desc.setWordWrap(True); hv.addWidget(desc)
        info=QtGui.QLabel("No activation-key screen. Online features require a deployed HTTPS service.")
        info.setObjectName("muted"); info.setWordWrap(True); hv.addWidget(info)
        svc=btn("Configure online service",True)
        svc.clicked.connect(self.open_settings); hv.addWidget(svc)
        outer.addWidget(hero)

        cards=QtGui.QHBoxLayout()
        c=QtGui.QFrame(); c.setObjectName("card")
        cv=QtGui.QVBoxLayout(c); cv.setContentsMargins(14,14,14,14); cv.setSpacing(8)
        plus=QtGui.QLabel("+"); plus.setStyleSheet("background:#3987f5;color:white;font-size:20px;font-weight:700;border-radius:10px;padding:5px;"); plus.setAlignment(QtCore.Qt.AlignCenter); plus.setFixedSize(42,42)
        cv.addWidget(plus)
        t=QtGui.QLabel("Create Party"); t.setStyleSheet("font-size:12pt;font-weight:700;"); cv.addWidget(t)
        d=QtGui.QLabel("Host a session and invite your team."); d.setObjectName("muted"); d.setWordWrap(True); cv.addWidget(d)
        b=btn("Create Party",True); b.clicked.connect(lambda:self.pages.setCurrentWidget(self.create_page)); cv.addWidget(b)
        cards.addWidget(c,1)

        c2=QtGui.QFrame(); c2.setObjectName("card")
        cv2=QtGui.QVBoxLayout(c2); cv2.setContentsMargins(14,14,14,14); cv2.setSpacing(8)
        arrow=QtGui.QLabel(">"); arrow.setStyleSheet("background:#304769;color:#a8caff;font-size:20px;font-weight:700;border-radius:10px;padding:5px;"); arrow.setAlignment(QtCore.Qt.AlignCenter); arrow.setFixedSize(42,42)
        cv2.addWidget(arrow)
        t2=QtGui.QLabel("Join Party"); t2.setStyleSheet("font-size:12pt;font-weight:700;"); cv2.addWidget(t2)
        d2=QtGui.QLabel("Enter a Party ID to join a friend."); d2.setObjectName("muted"); d2.setWordWrap(True); cv2.addWidget(d2)
        b2=btn("Join Party"); b2.clicked.connect(lambda:self.pages.setCurrentWidget(self.join_page)); cv2.addWidget(b2)
        cards.addWidget(c2,1)
        outer.addLayout(cards)

        recent=QtGui.QFrame(); recent.setObjectName("card")
        rv=QtGui.QVBoxLayout(recent); rv.setContentsMargins(14,12,14,12); rv.setSpacing(7)
        section=QtGui.QLabel("Recent projects"); section.setObjectName("section"); rv.addWidget(section)
        note=QtGui.QLabel("Add a project name manually when creating a party. SFM's active DMX is not scanned to avoid freezes.")
        note.setObjectName("muted"); note.setWordWrap(True); rv.addWidget(note)
        self.recent_project=QtGui.QLineEdit(self.config.get("recent_project",""))
        self.recent_project.setPlaceholderText("Project filename, e.g. my_scene.dmx")
        rv.addWidget(self.recent_project)
        saveproject=btn("Save project name")
        saveproject.clicked.connect(self.save_recent_project)
        rv.addWidget(saveproject)
        outer.addWidget(recent)

        bottom=QtGui.QHBoxLayout()
        people=btn("People"); people.clicked.connect(self.show_community)
        settings=btn("Settings"); settings.clicked.connect(self.open_settings)
        bottom.addWidget(people); bottom.addWidget(settings)
        outer.addLayout(bottom)
        outer.addStretch(1)
        self.pages.addWidget(self.home_page)

    def save_recent_project(self):
        project=str(self.recent_project.text()).strip()
        self.config["recent_project"]=project
        save_config(self.config)
        if self.party and project:
            self.party["project"]=project
        QtGui.QMessageBox.information(self,"Recent projects","Project name saved locally. Enter this filename when creating a party.")

    def _community_page(self):
        self.community_page=QtGui.QWidget(); outer=QtGui.QVBoxLayout(self.community_page)
        top=QtGui.QHBoxLayout(); back=btn("Back"); back.clicked.connect(lambda:self.pages.setCurrentWidget(self.home_page)); top.addWidget(back)
        title=QtGui.QLabel("Community"); title.setStyleSheet("font-size:20px;font-weight:bold;"); top.addWidget(title); top.addStretch(1)
        refresh=btn("Refresh"); refresh.clicked.connect(self.refresh_community); top.addWidget(refresh); outer.addLayout(top)
        self.community_status=QtGui.QLabel("Offline. Set the HTTPS service URL in Settings."); self.community_status.setObjectName("muted"); self.community_status.setWordWrap(True); outer.addWidget(self.community_status)
        tabs=QtGui.QHBoxLayout()
        self.tab_buttons={}
        for label in ("Friends","Everyone","Parties"):
            b=btn(label, label=="Friends"); b.clicked.connect(lambda checked=False,t=label:self.set_community_tab(t))
            self.tab_buttons[label]=b; tabs.addWidget(b)
        outer.addLayout(tabs)
        ar=QtGui.QHBoxLayout(); self.friend_input=QtGui.QLineEdit(); self.friend_input.setPlaceholderText("Friend's nickname"); self.friend_input.setMaxLength(20)
        add=btn("Add",True); add.clicked.connect(self.add_friend); ar.addWidget(self.friend_input,1); ar.addWidget(add); outer.addLayout(ar); self.friend_add=add
        self.search=QtGui.QLineEdit(); self.search.setPlaceholderText("Search by nickname"); self.search.textChanged.connect(self.refresh_community); outer.addWidget(self.search)
        self.rows=QtGui.QVBoxLayout(); self.rows.setSpacing(6)
        content=QtGui.QWidget(); content.setLayout(self.rows)
        scroll=QtGui.QScrollArea(); scroll.setWidgetResizable(True); scroll.setWidget(content); outer.addWidget(scroll,1)
        self.pages.addWidget(self.community_page)
        self.refresh_community()

    def _create_page(self):
        self.create_page=QtGui.QWidget(); v=QtGui.QVBoxLayout(self.create_page)
        title=QtGui.QLabel("Create a party"); title.setStyleSheet("font-size:20px;font-weight:bold;"); v.addWidget(title)
        v.addWidget(QtGui.QLabel("Project (DMX)"))
        self.dmx=QtGui.QLineEdit(); self.dmx.setPlaceholderText("Loaded project .dmx filename (enter manually)"); v.addWidget(self.dmx)
        self.dmx_note=QtGui.QLabel("SFM active-project detection varies by build; enter the filename if needed."); self.dmx_note.setObjectName("muted"); self.dmx_note.setWordWrap(True); v.addWidget(self.dmx_note)
        v.addWidget(QtGui.QLabel("Party password (optional)")); self.create_password=QtGui.QLineEdit(); self.create_password.setEchoMode(QtGui.QLineEdit.Password); v.addWidget(self.create_password)
        create=btn("Create Party",True); create.clicked.connect(self.create_party); v.addWidget(create)
        back=btn("Back"); back.clicked.connect(lambda:self.pages.setCurrentWidget(self.home_page)); v.addWidget(back); v.addStretch(1)
        self.pages.addWidget(self.create_page)

    def _join_page(self):
        self.join_page=QtGui.QWidget(); v=QtGui.QVBoxLayout(self.join_page)
        title=QtGui.QLabel("Join Party"); title.setStyleSheet("font-size:20px;font-weight:bold;"); v.addWidget(title)
        v.addWidget(QtGui.QLabel("Party ID")); self.party_id=QtGui.QLineEdit(); self.party_id.setPlaceholderText("SLM-ABC123"); v.addWidget(self.party_id)
        v.addWidget(QtGui.QLabel("Party password")); self.join_password=QtGui.QLineEdit(); self.join_password.setEchoMode(QtGui.QLineEdit.Password); v.addWidget(self.join_password)
        join=btn("Ask to Join",True); join.clicked.connect(self.join_party); v.addWidget(join)
        back=btn("Back"); back.clicked.connect(lambda:self.pages.setCurrentWidget(self.home_page)); v.addWidget(back); v.addStretch(1)
        self.pages.addWidget(self.join_page)

    def _party_page(self):
        self.party_page=QtGui.QWidget(); outer=QtGui.QVBoxLayout(self.party_page)
        scroll=QtGui.QScrollArea(); scroll.setWidgetResizable(True); content=QtGui.QWidget(); v=QtGui.QVBoxLayout(content)
        self.party_title=QtGui.QLabel("Party"); self.party_title.setStyleSheet("font-size:18px;font-weight:bold;"); v.addWidget(self.party_title)
        self.project_label=QtGui.QLabel("No DMX project selected"); self.project_label.setObjectName("muted"); v.addWidget(self.project_label)
        self.party_code_label=QtGui.QLabel("Party ID"); self.party_code_label.setStyleSheet("font-size:16px;font-weight:bold;"); v.addWidget(self.party_code_label)
        self.players_label=QtGui.QLabel("Players 0/5"); v.addWidget(self.players_label)
        self.party_status=QtGui.QLabel("Waiting for online service"); self.party_status.setObjectName("muted"); self.party_status.setWordWrap(True); v.addWidget(self.party_status)
        v.addWidget(QtGui.QLabel("Players")); self.players_list=QtGui.QListWidget(); self.players_list.setMinimumHeight(110); v.addWidget(self.players_list)
        role_row=QtGui.QHBoxLayout(); self.role_combo=QtGui.QComboBox(); self.role_combo.addItems(["Director","Animator"]); role_row.addWidget(self.role_combo)
        role_btn=btn("Set role"); role_btn.clicked.connect(self.set_role); role_row.addWidget(role_btn); v.addLayout(role_row)
        v.addWidget(QtGui.QLabel("Join requests")); self.requests_list=QtGui.QListWidget(); self.requests_list.setMaximumHeight(100); v.addWidget(self.requests_list)
        rr=QtGui.QHBoxLayout(); accept=btn("Accept",True); accept.clicked.connect(lambda:self.decide_request("accept")); reject=btn("Reject"); reject.clicked.connect(lambda:self.decide_request("reject")); rr.addWidget(accept); rr.addWidget(reject); v.addLayout(rr)
        v.addWidget(QtGui.QLabel("Voice chat")); voice=btn("Join voice chat"); voice.clicked.connect(self.voice_notice); v.addWidget(voice)
        voice_note=QtGui.QLabel("Voice chat transport is not included in this build."); voice_note.setObjectName("muted"); v.addWidget(voice_note)
        v.addWidget(QtGui.QLabel("Chat")); self.chat_log=QtGui.QTextEdit(); self.chat_log.setReadOnly(True); self.chat_log.setMinimumHeight(110); v.addWidget(self.chat_log)
        cr=QtGui.QHBoxLayout(); self.chat_input=QtGui.QLineEdit(); self.chat_input.setPlaceholderText("Write a message..."); send=btn("Send",True); send.clicked.connect(self.send_chat); picture=btn("Picture"); picture.clicked.connect(self.picture_notice); cr.addWidget(self.chat_input,1); cr.addWidget(picture); cr.addWidget(send); v.addLayout(cr)
        self.go_frame=btn("Go to frame"); self.go_frame.clicked.connect(self.go_to_frame_notice); v.addWidget(self.go_frame)
        self.close_party_btn=btn("Close party",False,True); self.close_party_btn.clicked.connect(self.leave_party); v.addWidget(self.close_party_btn)
        scroll.setWidget(content); outer.addWidget(scroll); self.pages.addWidget(self.party_page)

    def _settings_page(self):
        self.settings_page=QtGui.QWidget(); v=QtGui.QVBoxLayout(self.settings_page)
        title=QtGui.QLabel("Settings"); title.setStyleSheet("font-size:20px;font-weight:bold;"); v.addWidget(title)
        self.settings_nick=QtGui.QLabel(""); v.addWidget(self.settings_nick)
        change=btn("Change nickname"); change.clicked.connect(lambda:self.pages.setCurrentWidget(self.nick_page)); v.addWidget(change)
        v.addWidget(QtGui.QLabel("Online service URL (HTTPS)"))
        self.service_url=QtGui.QLineEdit(self.config.get("service_url","")); self.service_url.setPlaceholderText("https://your-service.onrender.com"); v.addWidget(self.service_url)
        note=QtGui.QLabel("Both users must use the same deployed HTTPS URL."); note.setObjectName("muted"); note.setWordWrap(True); v.addWidget(note)
        self.share_files=QtGui.QCheckBox("Share my files with my party"); self.share_files.setChecked(bool(self.config.get("file_sharing",False))); v.addWidget(self.share_files)
        self.far_players=QtGui.QCheckBox("Show far-away players as a small marker"); self.far_players.setChecked(bool(self.config.get("far_players",True))); v.addWidget(self.far_players)
        self.show_pings=QtGui.QCheckBox("Show pings and notes in the 3D view"); self.show_pings.setChecked(bool(self.config.get("show_pings",True))); v.addWidget(self.show_pings)
        v.addWidget(QtGui.QLabel("Player camera size")); self.camera_size=QtGui.QSlider(QtCore.Qt.Horizontal); self.camera_size.setRange(1,5); self.camera_size.setValue(int(self.config.get("camera_size",3))); v.addWidget(self.camera_size)
        save=btn("Save",True); save.clicked.connect(self.save_settings); v.addWidget(save)
        cancel=btn("Cancel"); cancel.clicked.connect(self.return_from_settings); v.addWidget(cancel); v.addStretch(1)
        self.pages.addWidget(self.settings_page)

    def save_nickname(self):
        name=str(self.nick.text()).strip()
        if len(name)<3 or len(name)>20 or any(not (c.isalnum() or c in " _-") for c in name):
            QtGui.QMessageBox.warning(self,"Nickname","Use 3-20 letters, numbers, spaces, _ or -."); return
        self.config["nickname"]=name; save_config(self.config)
        if hasattr(self,"welcome"): self.welcome.setText("Welcome back, %s" % name)
        self.pages.setCurrentWidget(self.home_page); self.connect_online()

    def open_settings(self):
        self.settings_nick.setText(self.config.get("nickname","")); self.service_url.setText(self.config.get("service_url","")); self.pages.setCurrentWidget(self.settings_page)

    def save_settings(self):
        self.config["service_url"]=str(self.service_url.text()).strip().rstrip("/")
        self.config["file_sharing"]=self.share_files.isChecked()
        self.config["far_players"]=self.far_players.isChecked()
        self.config["show_pings"]=self.show_pings.isChecked()
        self.config["camera_size"]=self.camera_size.value()
        save_config(self.config); self.return_from_settings(); self.connect_online()

    def return_from_settings(self):
        self.pages.setCurrentWidget(self.party_page if self.party else self.home_page)

    def show_community(self):
        self.pages.setCurrentWidget(self.community_page); self.refresh_community()

    def set_community_tab(self,tab):
        self.community_tab=tab
        for name,b in self.tab_buttons.items(): b.setStyleSheet("background:#3987f5;" if name==tab else "")
        self.refresh_community()

    def is_online(self):
        return bool(self.manager is not None and str(self.config.get("service_url","")).startswith("https://") and self.config.get("token"))

    def api(self,method,path,payload,callback):
        base=str(self.config.get("service_url","")).strip().rstrip("/")
        if self.manager is None:
            callback(False,{"error":"QtNetwork is unavailable in this SFM build."},0); return
        if not base.startswith("https://"):
            callback(False,{"error":"Set a deployed HTTPS URL in Settings."},0); return
        try:
            request=QtNetwork.QNetworkRequest(QtCore.QUrl(base+path))
            request.setHeader(QtNetwork.QNetworkRequest.ContentTypeHeader,"application/json")
            token=self.config.get("token","")
            if token: request.setRawHeader(QtCore.QByteArray("Authorization"),QtCore.QByteArray("Bearer "+str(token)))
            body=QtCore.QByteArray(json.dumps(payload or {}))
            if method=="GET": reply=self.manager.get(request)
            elif method=="POST": reply=self.manager.post(request,body)
            elif method=="PUT": reply=self.manager.sendCustomRequest(request,QtCore.QByteArray("PUT"),body)
            elif method=="DELETE": reply=self.manager.sendCustomRequest(request,QtCore.QByteArray("DELETE"),body)
            else: callback(False,{"error":"Unsupported method."},0); return
            def done():
                try:
                    raw=reply.readAll()
                    try: response=raw.data()
                    except Exception: response=str(raw)
                    try: data=json.loads(response or "{}")
                    except Exception: data={"error":"Invalid response from service."}
                    try: status=int(reply.attribute(QtNetwork.QNetworkRequest.HttpStatusCodeAttribute) or 0)
                    except Exception: status=0
                    err=reply.error()
                    good=(err==QtNetwork.QNetworkReply.NoError and 200<=status<300)
                    if not good and status==0:
                        try: data["error"]=str(reply.errorString())
                        except Exception: pass
                    callback(good,data,status)
                except Exception:
                    log_exception(); callback(False,{"error":"Could not read service response."},0)
                reply.deleteLater()
            reply.finished.connect(done)
        except Exception:
            log_exception(); callback(False,{"error":"Could not create HTTPS request."},0)

    def connect_online(self):
        base=str(self.config.get("service_url","")).strip()
        if not base:
            if hasattr(self,"connection_label"): self.connection_label.setText("Offline - add the deployed HTTPS service URL in Settings")
            return
        if not base.startswith("https://"):
            QtGui.QMessageBox.warning(self,"Online service","Use an HTTPS URL. Plain HTTP is not accepted."); return
        if not self.config.get("nickname"):
            return
        if self.config.get("token"):
            self.api("POST","/api/heartbeat",{},self.heartbeat_result)
        else:
            self.register_user()

    def register_user(self):
        self.api("POST","/api/register",{"nickname":self.config.get("nickname","User")},self.register_result)

    def register_result(self,ok,data,status):
        if ok:
            self.config["token"]=data.get("token",""); self.config["user_id"]=data.get("user_id",""); save_config(self.config)
            self.connection_label.setText("Connected online as %s" % self.config.get("nickname","Player"))
            self.timer.start(10000); self.refresh_community()
        else:
            self.connection_label.setText(data.get("error","Online registration failed."))
            if status==409:
                QtGui.QMessageBox.warning(self,"Nickname already used",data.get("error","Choose another nickname."))

    def heartbeat_result(self,ok,data,status):
        if ok:
            self.connection_label.setText("Online as %s" % self.config.get("nickname","Player"))
            self.timer.start(10000)
            code=data.get("party_code")
            if code and (not self.party or self.party.get("id")!=code):
                self.api("GET","/api/parties/"+code,None,self.adopt_party_result)
        elif status==401:
            self.config.pop("token",None); self.config.pop("user_id",None); save_config(self.config); self.register_user()
        else:
            self.connection_label.setText(data.get("error","Online service unavailable."))

    def online_tick(self):
        if not self.config.get("token"): return
        self.api("POST","/api/heartbeat",{},self.heartbeat_result)
        if self.pages.currentWidget()==self.community_page: self.refresh_community()
        if self.party and self.pages.currentWidget()==self.party_page: self.refresh_party()

    def refresh_community(self):
        if not hasattr(self,"rows"): return
        if not self.is_online():
            self._clear_rows()
            self.community_status.setText("Offline. Deploy the service and enter its HTTPS URL in Settings.")
            self.friend_input.setVisible(self.community_tab=="Friends"); self.friend_add.setVisible(self.community_tab=="Friends")
            self.search.setVisible(self.community_tab!="Friends")
            self._add_row("Not connected","Live players and parties appear after connecting.","Settings",lambda:self.open_settings())
            return
        tab={"Friends":"friends","Everyone":"everyone","Parties":"parties"}[self.community_tab]
        search=str(self.search.text()).strip()
        import urllib
        try: quoted=urllib.quote(search.encode("utf-8"))
        except Exception:
            try:
                from urllib.parse import quote
                quoted=quote(search)
            except Exception: quoted=""
        self.api("GET","/api/community?tab=%s&search=%s"%(tab,quoted),None,lambda ok,data,status,t=tab:self.render_community(t,ok,data,status))

    def render_community(self,tab,ok,data,status):
        self._clear_rows()
        self.friend_input.setVisible(tab=="friends"); self.friend_add.setVisible(tab=="friends"); self.search.setVisible(tab!="friends")
        if not ok:
            self.community_status.setText(data.get("error","Could not load community (HTTP %s)"%status)); self._add_row("Service error","Check the service URL and deployment logs.","Retry",self.refresh_community); return
        self.community_status.setText("Online community - player presence is live.")
        count=0
        if tab=="friends":
            for u in data.get("friends",[]):
                name=u.get("nickname","Player"); detail="Online" if u.get("online") else "Offline"
                if u.get("party_code"): detail += " - In a party"
                self._add_row(name,detail,"Message",lambda checked=False,n=name:self.message_notice(n),secondary=("Remove",lambda checked=False,n=name:self.remove_friend(n))); count+=1
            for r in data.get("incoming_requests",[]):
                self._add_row(r.get("nickname","Player"),"Friend request","Accept",lambda checked=False,rid=r.get("id"):self.friend_respond(rid,"accept"),secondary=("Reject",lambda checked=False,rid=r.get("id"):self.friend_respond(rid,"reject"))); count+=1
            for r in data.get("outgoing_requests",[]):
                self._add_row(r.get("nickname","Player"),"Friend request sent","Pending",lambda:None); count+=1
        elif tab=="everyone":
            for u in data.get("users",[]):
                name=u.get("nickname","Player"); detail="Online" if u.get("online") else "Offline"
                if u.get("party_code"): detail+=" - In a party"
                if u.get("is_friend"): action="Message"; cb=lambda checked=False,n=name:self.message_notice(n)
                else: action="Add"; cb=lambda checked=False,n=name:self.add_friend_named(n)
                self._add_row(name,detail,action,cb); count+=1
        else:
            for p in data.get("parties",[]):
                code=p.get("code",""); owner=p.get("owner","Host")
                detail="%s - %s/%s players"%(code,p.get("player_count",1),p.get("max_players",5))
                if p.get("project"): detail+=" - "+p.get("project")
                if p.get("request_pending"): action="Request sent"; cb=lambda:None
                else: action="Ask to join"; cb=lambda checked=False,c=code:self.ask_to_join(c,"")
                self._add_row(owner+"'s Party",detail,action,cb); count+=1
        if not count: self._add_row("Nothing here yet","No matching players or parties found.","Refresh",self.refresh_community)

    def _clear_rows(self):
        while self.rows.count():
            item=self.rows.takeAt(0); w=item.widget()
            if w: w.deleteLater()

    def _add_row(self,name,detail,action,callback,secondary=None):
        f=QtGui.QFrame(); f.setObjectName("card"); h=QtGui.QHBoxLayout(f)
        avatar=QtGui.QLabel((name[:1] or "?").upper()); avatar.setAlignment(QtCore.Qt.AlignCenter); avatar.setFixedSize(34,34)
        avatar.setStyleSheet("background:#3987f5;color:white;border-radius:17px;font-weight:bold;")
        h.addWidget(avatar); vl=QtGui.QVBoxLayout(); title=QtGui.QLabel(name); title.setStyleSheet("font-weight:bold;")
        desc=QtGui.QLabel(detail); desc.setObjectName("muted"); desc.setWordWrap(True); vl.addWidget(title); vl.addWidget(desc); h.addLayout(vl,1)
        if secondary:
            b=btn(secondary[0]); b.clicked.connect(secondary[1]); h.addWidget(b)
        b2=btn(action,True); b2.clicked.connect(callback); h.addWidget(b2); self.rows.addWidget(f)

    def add_friend(self):
        self.add_friend_named(str(self.friend_input.text()).strip())

    def add_friend_named(self,name):
        name=str(name).strip()
        if not self.is_online(): QtGui.QMessageBox.information(self,"Online service","Connect online first."); return
        self.api("POST","/api/friends/request",{"nickname":name},lambda ok,data,status:self.action_result(ok,data,status))

    def friend_respond(self,rid,action):
        self.api("POST","/api/friends/respond",{"request_id":rid,"action":action},lambda ok,data,status:self.action_result(ok,data,status))

    def remove_friend(self,name):
        self.api("DELETE","/api/friends/"+self.url_quote(name),{},lambda ok,data,status:self.action_result(ok,data,status))

    def ask_to_join(self,code,password):
        self.api("POST","/api/parties/%s/requests"%code,{"password":password},lambda ok,data,status:self.action_result(ok,data,status))

    def action_result(self,ok,data,status):
        msg=data.get("message",data.get("error","Request finished."))
        self.community_status.setText(msg)
        if not ok: QtGui.QMessageBox.information(self,"SceneLink Lite",msg)
        self.refresh_community()

    def url_quote(self,value):
        try:
            import urllib
            return urllib.quote(str(value).encode("utf-8"))
        except Exception:
            try:
                from urllib.parse import quote
                return quote(str(value))
            except Exception:
                return ""

    def create_party(self):
        if not self.is_online(): QtGui.QMessageBox.information(self,"Online service","Connect online first in Settings."); return
        self.api("POST","/api/parties",{"project":str(self.dmx.text()).strip(),"password":str(self.create_password.text())},self.create_party_result)

    def create_party_result(self,ok,data,status):
        if not ok: QtGui.QMessageBox.warning(self,"Create Party",data.get("error","Could not create party.")); return
        self.set_party(data.get("party",{})); self.pages.setCurrentWidget(self.party_page); self.timer.start(5000); self.refresh_party()

    def join_party(self):
        code=str(self.party_id.text()).strip().upper()
        password=str(self.join_password.text())
        if not code: QtGui.QMessageBox.warning(self,"Join Party","Enter a Party ID."); return
        if not self.is_online(): QtGui.QMessageBox.information(self,"Online service","Connect online first in Settings."); return
        self.ask_to_join(code,password)

    def set_party(self,p):
        self.party={"id":p.get("code",""),"owner":p.get("owner","Host"),"project":p.get("project",""),"players":p.get("players",[]),"join_requests":p.get("join_requests",[]),"online":True}
        self.party_code_label.setText("Party ID: "+self.party["id"]); self.party_title.setText(self.party["owner"]+"'s Party")
        self.project_label.setText(self.party["project"] or "No DMX project selected")
        self.update_party_widgets()

    def adopt_party_result(self,ok,data,status):
        if ok:
            self.set_party(data.get("party",{})); self.pages.setCurrentWidget(self.party_page); self.refresh_party()
        elif status==403:
            self.connection_label.setText("Waiting for host to accept your join request.")

    def refresh_party(self):
        if not self.party or not self.party.get("online"): return
        code=self.party.get("id")
        self.api("GET","/api/parties/"+code,None,self.party_result)
        self.api("GET","/api/parties/"+code+"/chat?since=%s"%int(self.party.get("last_message_id",0)),None,self.chat_result)

    def party_result(self,ok,data,status):
        if not ok:
            if status==403:
                self.party_status.setText("Join request is pending or you are no longer in this party.")
            else: self.party_status.setText(data.get("error","Party refresh failed."))
            return
        self.set_party(data.get("party",{}))
        self.party_status.setText("Online - party membership synced.")
        self.refresh_request_list()

    def update_party_widgets(self):
        if not self.party: return
        self.party_title.setText(self.party.get("owner","Host")+"'s Party")
        self.project_label.setText(self.party.get("project") or "No DMX project selected")
        self.party_code_label.setText("Party ID: "+self.party.get("id",""))
        players=self.party.get("players",[])
        self.players_label.setText("Players %d/5"%len(players))
        self.players_list.clear()
        for p in players:
            self.players_list.addItem("%s | %s%s"%(p.get("name",p.get("nickname","Player")),p.get("role","Director")," (Host)" if p.get("host") else ""))
        self.close_party_btn.setText("Close party" if any(p.get("host") and p.get("name")==self.config.get("nickname") for p in players) else "Leave party")

    def refresh_request_list(self):
        self.requests_list.clear()
        reqs=self.party.get("join_requests",[]) if self.party else []
        if not reqs: self.requests_list.addItem("No pending requests.")
        else:
            for r in reqs: self.requests_list.addItem("%s (request %s)"%(r.get("name","Player"),r.get("id","?")))

    def decide_request(self,action):
        if not self.party: return
        row=self.requests_list.currentRow(); reqs=self.party.get("join_requests",[])
        if row<0 or row>=len(reqs): QtGui.QMessageBox.information(self,"Join requests","Select a pending request first."); return
        req=reqs[row]
        self.api("POST","/api/parties/%s/requests/%s"%(self.party.get("id"),req.get("id")),{"action":action},lambda ok,data,status:self.party_action_result(ok,data,status))

    def party_action_result(self,ok,data,status):
        if not ok: QtGui.QMessageBox.warning(self,"Party",data.get("error","Action failed."))
        self.refresh_party()

    def set_role(self):
        row=self.players_list.currentRow()
        if row<0: QtGui.QMessageBox.information(self,"Roles","Select a player."); return
        p=self.party.get("players",[])[row]
        name=p.get("name",p.get("nickname",""))
        self.api("PUT","/api/parties/%s/roles"%self.party.get("id"),{"nickname":name,"role":str(self.role_combo.currentText())},lambda ok,data,status:self.party_action_result(ok,data,status))

    def send_chat(self):
        text=str(self.chat_input.text()).strip()
        if not text or not self.party: return
        self.api("POST","/api/parties/%s/chat"%self.party.get("id"),{"text":text},lambda ok,data,status:self.chat_send_result(ok,data,status))
        self.chat_input.clear()

    def chat_send_result(self,ok,data,status):
        if not ok: self.party_status.setText(data.get("error","Message failed."))
        self.refresh_party()

    def chat_result(self,ok,data,status):
        if not ok: return
        for m in data.get("messages",[]):
            mid=int(m.get("id",0))
            if mid>int(self.party.get("last_message_id",0)):
                txt=m.get("text","").replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")
                self.chat_log.append("<b>%s:</b> %s"%(m.get("nickname","Player"),txt))
                self.party["last_message_id"]=mid

    def leave_party(self):
        if not self.party: return
        is_owner=self.party.get("owner")==self.config.get("nickname")
        label="Close party for everyone?" if is_owner else "Leave this party?"
        reply=QtGui.QMessageBox.question(self,"SceneLink Lite",label,QtGui.QMessageBox.Yes|QtGui.QMessageBox.No,QtGui.QMessageBox.No)
        if reply!=QtGui.QMessageBox.Yes: return
        code=self.party.get("id")
        self.api("DELETE","/api/parties/"+code,{},self.leave_result)

    def leave_result(self,ok,data,status):
        if not ok: QtGui.QMessageBox.warning(self,"Party",data.get("error","Could not leave party."))
        self.party=None; self.pages.setCurrentWidget(self.home_page); self.refresh_community()

    def message_notice(self,name):
        QtGui.QMessageBox.information(self,"Direct message","Direct messages are a later milestone. Party text chat is available in online parties.")

    def voice_notice(self):
        QtGui.QMessageBox.information(self,"Voice chat","Live audio requires a separate WebRTC/voice transport and is not implemented in this online-service build.")

    def picture_notice(self):
        QtGui.QMessageBox.information(self,"Picture","Image upload and transfer are not implemented yet. This build does not send local files to the service.")

    def go_to_frame_notice(self):
        QtGui.QMessageBox.information(self,"Go to frame","Remote timeline/frame sync requires deeper SFM timeline integration and is not implemented yet.")

    def save_nickname(self):
        name=str(self.nick.text()).strip()
        if len(name)<3 or len(name)>20 or any(not (c.isalnum() or c in " _-") for c in name):
            QtGui.QMessageBox.warning(self,"Nickname","Use 3-20 letters, numbers, spaces, _ or -."); return
        self.config["nickname"]=name; save_config(self.config)
        if hasattr(self,"welcome"): self.welcome.setText("Welcome back, %s" % name)
        self.pages.setCurrentWidget(self.home_page); self.connect_online()

    def closeEvent(self,event):
        event.accept()

def show():
    global APP,WINDOW
    if QtGui is None or QtCore is None:
        return
    try:
        APP=QtGui.QApplication.instance()
        if APP is None: APP=QtGui.QApplication([])
        WINDOW=SceneLinkWindow()
        WINDOW.show(); WINDOW.raise_(); WINDOW.activateWindow()
    except Exception:
        log_exception()
        try: QtGui.QMessageBox.critical(None,"SceneLink Lite","Failed to open the online UI. Check scenelink_lite_debug.log in your home folder.")
        except Exception: pass

if __name__=="__main__":
    show()
