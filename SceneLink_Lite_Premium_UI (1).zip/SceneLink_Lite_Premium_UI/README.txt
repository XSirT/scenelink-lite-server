SCENELINK LITE ONLINE SERVICE PACK
==================================

What this build actually connects
---------------------------------
- Nickname registration and online presence
- Community: Friends, Everyone, Parties
- Add friend by registered nickname; incoming friend requests can be accepted/rejected
- Create a party with an optional password and displayed DMX filename
- Public party listing and Ask to Join
- Host approval/rejection of join requests
- Up to five members per party
- Owner can assign Director or Animator
- Party text chat
- HTTPS requests through QtNetwork; no changes to SFM Python installation

Not implemented in this milestone
---------------------------------
- Voice chat audio transport
- Image upload/transfer
- Live DMX, animation, camera, or timeline synchronization
- In-viewport player markers
- Direct messages outside party chat
- Production-grade moderation/rate limiting or account recovery

Required deployment step
------------------------
The backend needs a public HTTPS URL so two PCs in different countries can reach it.
I cannot deploy it under your hosting account from this ZIP.

One route is Render:
1. Put app.py, requirements.txt, and render.yaml into a Git repository.
2. In Render, create a Python Web Service connected to the repository.
3. Build command: pip install -r requirements.txt
4. Start command: gunicorn app:app
5. After deployment, copy the HTTPS URL (like https://your-name.onrender.com).
6. In SFM, open SceneLink Lite > Settings and paste that URL into Online service URL.
7. Both you and your friend use the same URL, but register different nicknames.

Official Render Flask deployment guide:
https://render.com/docs/deploy-flask

Important deployment details
----------------------------
- The default SQLite database file may be reset on some free-host restarts/redeploys.
  For persistent accounts, configure persistent storage or managed PostgreSQL later.
- This service is a prototype. It stores a hashed bearer token, but a stolen client
  token grants access to that account. Keep %USERPROFILE%\scenelink_lite_settings.json private.
- Use only an HTTPS URL you trust. Do not use plain HTTP. Do not disable certificate
  checks or open router ports on your home PC.
- The service API does not show one player another player's IP address, although the
  hosting provider will see normal connection metadata.
- This client requires QtNetwork in the SFM Qt build and successful TLS verification.
  If SFM's Qt/OpenSSL build cannot validate the host certificate, the UI should report
  a connection error; do not switch to insecure HTTP.

Install client
--------------
1. Close SFM.
2. Back up scenelink_lite.py outside the SFM scripts folder.
3. Replace it with the scenelink_lite.py from this package.
4. Restart SFM and open SceneLink Lite.
5. Set the service URL after deployment. If no URL is set, the app remains offline.

This is an early online milestone; do not treat the service as a fully launched public
platform. Voice and scene syncing are separate engineering tasks.


PREMIUM UI REFRESH
------------------
This build updates only the original SceneLink Lite client written for this project.
It uses a polished dark dashboard, rounded gradient buttons with hover/pressed states,
a Community Build card, Create/Join Party cards, and a manual recent-project filename
field. It intentionally does not scan the SFM installation for DMX files because the
earlier recursive scan could cause SFM to hang.

No activation-key screen has been added to SceneLink Lite. This is an independent
client and does not remove or bypass licensing in MYFRIENDOLD.py or the proprietary
SFM Collaboration application.

The online service is still a separate deployment. Voice chat, image transfer, and
live DMX/timeline synchronization remain unimplemented.
